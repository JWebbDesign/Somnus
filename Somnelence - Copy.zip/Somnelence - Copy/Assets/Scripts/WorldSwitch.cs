using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class WorldSwitch : MonoBehaviour
{

    public GameObject Reality;
    public GameObject Dream;
    public GameObject Trigger;
    public GameObject Roadblock;

    // Update is called once per frame
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            Reality.SetActive(false);
            Dream.SetActive(true);
            Destroy(Trigger);
            Destroy(Roadblock);

        }
    } 
}
