using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoxRunAnim : MonoBehaviour
{
    [SerializeField] private Animator fox;
    [SerializeField] private string open = "FoxRun";
    public bool playerInRange;

    void Update()
    {

    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Player"))
        {
            fox.Play(open,0,0.0f);

        }
    }
}
