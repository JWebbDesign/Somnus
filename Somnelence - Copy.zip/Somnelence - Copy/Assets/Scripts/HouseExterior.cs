using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HouseExterior : MonoBehaviour
{
    public Animator camAnim;
    public GameObject player;
    public GameObject trigger;
    public GameObject house;
    public GameObject house2;
    

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject == player)
        {
            camAnim.SetBool("expand", true);
            Debug.Log("House Appears");
            house.SetActive(true);
            house2.SetActive(true);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        camAnim.SetBool("expand", false);
        Debug.Log("House Disappears");
        house.SetActive(false);
        house2.SetActive(false);
    }
}
